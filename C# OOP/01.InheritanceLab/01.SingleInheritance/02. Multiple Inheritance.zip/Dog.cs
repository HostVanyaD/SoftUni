﻿using System;
namespace Farm
{
    public class Dog : Animal
    {
        public Dog()
        {

        }

        public void Bark()
        {
            Console.WriteLine("barking...");
        }
    }
}
