﻿using System;

namespace Farm
{
    public class Puppy : Dog
    {
        public Puppy()
        {

        }

        public void Weep()
        {
            Console.WriteLine("weeping...");
        }
    }
}
