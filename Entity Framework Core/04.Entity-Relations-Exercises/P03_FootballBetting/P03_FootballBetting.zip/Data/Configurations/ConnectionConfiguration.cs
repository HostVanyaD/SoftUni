﻿namespace P03_FootballBetting.Data.Configurations
{
    internal static class ConnectionConfiguration
    {
        internal const string CONNECTION_STRING =
            @"Server=.;Database=FootballBetting;Integrated Security=true;";
    }
}
