﻿namespace P01_StudentSystem.Data.Configurations
{
    public static class ConnectionConfiguration
    {
        public const string CONNECTION_STRING =
            @"Server=.;Database=StudentSystem;Integrated Security=true;";
    }
}
