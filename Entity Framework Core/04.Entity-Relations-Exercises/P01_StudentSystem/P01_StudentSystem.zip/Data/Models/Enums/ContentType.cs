﻿namespace P01_StudentSystem.Models.Enums
{
    public enum ContentType
    {
        Application,
        Pdf,
        Zip
    }
}
