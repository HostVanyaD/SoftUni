﻿namespace P01_StudentSystem.Models.Enums
{
    public enum ResourceType
    {
        Video,
        Presentation,
        Document,
        Other
    }
}
